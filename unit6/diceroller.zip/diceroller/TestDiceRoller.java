/**
 * Tests the Dice Roller class to check that it produces
 * random rolls properly.
 */
public class TestDiceRoller {

    public static void main ( String [] args ) {
        DiceRoller d = new DiceRoller( );

        for ( int i=0; i<100; i++ ) {
            d.roll();
        }
        System.out.println ( d );

        for ( int i=0; i<900; i++ ) {
            d.roll();
        }
        System.out.println ( d );
        int step=5;
        for ( int r=2; r<=12; r++ ) {
            System.out.format ("%3d: ", r );
            for ( int c=step; c<d.getCount()/2; c+=step ) {
                if ( d.getRolls(r) > c) {
                    System.out.print("#");
                }
            }
            System.out.println ( );
        }

    }

}