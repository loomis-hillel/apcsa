/**
 * A program that simulates rolling two pairs of dice. The
 * counts of the dice rolls are kept and can be obtained
 * for each denomination.
 * @author
 * @version
 */
public class DiceRoller {

    // Add your code here
    
}