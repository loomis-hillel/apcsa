/**
  * This program will test the Bag that students create
  * as part of a lab exercise.
  * @author Ken Loomis
  */
public class TestBag {

    private static final String [] items = 
        {"Milk", "Eggs", "Cereal", "Bread", "Sugar", "Salt", "Ice Cream" };

    public static void main ( String [] args ) {

        Bag bag = new Bag ( 3 );

        int i=0;
        while ( !bag.isFull() ) {
            bag.add ( items[i] );
            i++;
        }
        // Should contain Milk, Eggs, & Cereal
        System.out.println ( bag );

        // Should remove Cereal, Eggs, & Milk (in that order)
        while ( !bag.isEmpty() ) {
            bag.get ( );
            System.out.println ( bag );
        }

        bag = new Bag( );
        for ( String item : items ) {
            bag.add ( item );
        }

        // Should contain "Milk", "Eggs", "Cereal", "Bread", "Sugar", "Salt", & "Ice Cream"
        System.out.println ( bag );

        for ( i=0; i<items.length; i+=3 ) {
            System.out.println ( "Remove " + bag.get(items[i]) );
        }

        // Should contain "Sugar", "Eggs", "Cereal", "Salt"
        System.out.println ( bag );

    }

}