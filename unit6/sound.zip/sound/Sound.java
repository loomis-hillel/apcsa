/**
 * Represents a simple sound wave form as an array of 
 */
public class Sound {

	/** the array of values in this sound; guaranteed not to be null */
	private int[] samples;

	/** Prevents use of default constructor **/
	private Sound ( ) {
		/* do nothing */
	}
	
	/**
	 * Instantiates a sound using the given array of samples 
	 * @param samples the initial array of sound samples
	 * 	      Precondition: samples contains at least one nonzero value
	 */
	public Sound(int [] samples) {
		/* to be completed in Task 1 */
	}

	/**
	 * Produces the length of the sound in terms of the number of samples.
	 * Actually length of sound in seconds depends on sample frequency. 
	 * @return the number of samples in the sound
	 */
	public int getLength ( ) {
		return samples.length; 
	}
	

	/** Changes those values in this sound that have an amplitude
	 *  outside the allowed amplitude range.
	 *  Postcondition: Values greater than max are changed to max and
	 *  values less than min are changed to min.
	 *  @param min the amplitude minimum limit
	 *         Precondition: min <= 0
	 *  @param max the amplitude maximum limit
	 *         Precondition: max >= 0
	 *  @return the number of values in this sound that this
	 *    method changed
	 */
	public int limitAmplitude(int min, int max) { 
		/* to be completed in Task 3 */
		return 0;
	}


	/** Removes all silence from the beginning of this sound (except 1 sample).
	 *  Silence is represented by a value of 0.
	 *  Precondition: samples contains at least one nonzero value
	 *  Postcondition: the length of samples reflects the
	 *                  removal of starting silence
	 *  Side effect: if there is no silence in the recording a 1 sample size
	 *               section of silence will be added.
	 */
	public void leftTrim() { 
		/* to be completed in Task 4 */
	}
	
	/** Removes all silence from the end of this sound (except 1 sample).
	 *  Silence is represented by a value of 0.
	 *  Precondition: samples contains at least one nonzero value
	 *  Postcondition: the length of samples reflects the
	 *                  removal of ending silence
	 *  Side effect: if there is no silence in the recording a 1 sample size
	 *               section of silence will be added.
	 */
	public void rightTrim() { 
		/* to be completed in Task 5 */

	}
	
	@Override
	public String toString() {
		/* to be completed in Task 2 */
	}



}
