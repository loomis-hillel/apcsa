/**
  * This program tests the Sound class. It uses one short sample wave form
  * to test the capabilites of the sound class.
  */
public class TestSound {

	public static void main(String[] args) {
				
		int [] samples = {0, 0, 0, 0, 0, -5, -14, -21, -35, -39, -31, -15, -3, 0, 7, 16, 32, 37, 29, 25, 11, 0, 0, 0, 0};
		Sound s = new Sound ( samples );
		
		// Sound: 0, 0, 0, 0, 0, -5, -14, -21, -35, -39, -31, -15, -3, 0, 7, 16, 32, 37, 29, 25, 11, 0, 0, 0, 0,
		System.out.println( s );
		
		// Changed: 5
		// Sound: 0, 0, 0, 0, 0, -5, -14, -21, -30, -30, -30, -15, -3, 0, 7, 16, 30, 30, 29, 25, 11, 0, 0, 0, 0,
		System.out.println ( "Changed: " + s.limitAmplitude(-30, 30) );
		System.out.println( s );
		
		// Sound: -5, -14, -21, -30, -30, -30, -15, -3, 0, 7, 16, 30, 30, 29, 25, 11, 0, 0, 0, 0,
		s.leftTrim();
		System.out.println( s );
		
		// Sound: -5, -14, -21, -30, -30, -30, -15, -3, 0, 7, 16, 30, 30, 29, 25, 11,
		s.rightTrim();
		System.out.println( s );
		
	}

}
