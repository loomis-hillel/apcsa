/**
  * A program to test the functionality of the RandArray class.
  */
public class TestRandArray {

    /**
     * Creates multiple random arrays of various sizes.
     * Then outputs the sun, average, and standard 
     * deviation of each array.
     */
    public static void main ( String [] args ) {
        RandArray rand = new RandArray( );
        System.out.print ( rand );
        System.out.println ( "Sum = " + rand.sum() );
        System.out.println ( "Avg = " + rand.average() );
        System.out.println ( "Std dev = " + rand.stddev() );
        System.out.println();

        rand = new RandArray( 50 );
        System.out.print ( rand );
        System.out.println ( "Sum = " + rand.sum() );
        System.out.println ( "Avg = " + rand.average() );
        System.out.println ( "Std dev = " + rand.stddev() );
        System.out.println();

        System.out.println ( "Size\t          Sum\tAverage\tStd Dev\n" + 
                             "--------------------------------------------" );
        for ( int i=1; i<=50; i++ ) {
            rand = new RandArray( 200*i );
            System.out.format ( "%d\t%12d\t%5.2f\t%5.2f\n", 200*i, 
                rand.sum(), rand.average(), rand.stddev() );
        }

    }

}