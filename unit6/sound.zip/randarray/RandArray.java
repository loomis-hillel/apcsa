/**
 * Holds an array of random values.
 * @author
 * @version
 */
public class RandArray {

    /** An array of ints defined with a capacity equal to the given capacity **/
    int [] randomNumbers;

    /**
     * Constructs the array with a capacity of 10 by default.
     * Fills the array with random numbers between 1 and 1000 (inclusive)
     */
    public RandArray ( ) {
        this ( 10 );
    }

    /**
     * Constructs the array with a capacity given.
     * Precondition: the given size is between 1 and 10000.
     * Postcondition: fills the array with random numbers between 1 and 1000 (inclusive).
     * @param size, int, the capacity of the array.
     */
    public RandArray ( int size ) {
        // This if statement protects the class by preventing an invalid size being used.
        if ( size < 1 || size > 10000 ) {
            throw new IllegalArgumentException( "Invalid array size" );
        }
        // Task 1: Create the array and randomize it.
        
    }

    /**
     * Fills the array with random numbers between 1 and 1000 inclusive.
     */
    public void randomize ( ) {
        // Task 2: Complete this method so that it fills the array with 
        // random values.

    }

    /**
     * Calculates the sum of the values that are in the array.
     */
    public int sum ( ) {
        // Task 3: Complete this method so that it calculates the total of
        // of all the values in the array.
        int total = 0;
        
        return total;
    }

    /**
     * Calculates the average of the values that are in the array.
     */
    public double average ( ) {
        if ( randomNumbers != null ) {
            return (double) sum() / randomNumbers.length;
        }
        return 0;
    }

    /**
     * Calculates the standard deviation of the values in the array.
     */
    public double stddev ( ) {
        // Task #4: update this method to calculate the standard deviation
        double stddev = 0;
        double variance = 0;
        double avg = average();
        
        return stddev; // update this so it doesn't just return 0.
    }

    @Override
    public String toString ( ) {
        String s = "";
        int len = 0;
        if ( randomNumbers != null ) {
            len = randomNumbers.length;
        }
        s = "RandArray of size " + len + ":\n";
        for ( int i=0; i < len; i++ ) {
            s += randomNumbers[i] + ", ";
            if ( i%10 == 9 ) {
                s += "\n";
            }
        }
        return s;
    }

}