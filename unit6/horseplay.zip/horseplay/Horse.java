/**
 * Represents a horse with a name and weight in pounds.
 * @author Ken Loomis
 * @version 2023
 */
public class Horse
{
    /** The horse's name */
    private String name;

    /** The horse's weight in pounds */
    private double weight;

    private Horse ( ) { /* Do nothing */ }

    /**
     * Creates a horse with the given name and weight
     */
    public Horse ( String name, double weight ) {
        this.name = name;
        this.weight = weight;
    }

   /**
    * Produces the horse's name
    * @return string - the horse's name 
    */
   public String getName() { return name; }

   /**
    * Produces the horse's weight in pounds
    * @return double - the horse's weight 
    */
   public double getWeight() { return weight; }

   /**
    * Compares two horse's to see if they are the
    * same horse. 
    * Postcondition: The horses are equal if their names
    * are the same.
    */
    public boolean equals ( Horse other ) {
        return other != null && this.name.equals(other.name);
    }

}