/**
 * Represents a horse with a name and weight in pounds.
 * @author Ken Loomis
 * @version 2023
 */
public class Barn
{
    /** An array of horses used to test your array */
    private static final Horse [] HERD = { new Horse ( "Silver", 1210.0 ),
                                           new Horse ( "Trigger", 1340.0 ),
                                           new Horse ( "Patches", 1315.5 ), 
                                           new Horse ( "Duke", 1423.0 ), 
                                           new Horse ( "Spirit", 1170.5 ), 
                                           new Horse ( "Hidalgo", 1250.0 ), 
                                           new Horse ( "Black Beauty", 1305.0 ),
                                           new Horse ( "Shaytan", 1249.0 ) };

    public static void main ( String [] args ) {
        /* Task 1: Create an array to represent the stalls of a barn
           that can old 10 horses. Plenty large enough to hold the 
           herd of horses. */
               
        displayBarn ( ? );

        /* Task 3: Iterate through the contents of the HERD array and 
           assign each horse to a random position in the barn array
           created in task #1. If the stall is already occupied then
           do not add the horse to the barn. */
        
        displayBarn ( ? );

        /* Task 4: Search for the first and last horses of the herd
           to see where they are in the array. Search for both horses
           at the same time. Indicate where the index position of the
           stall where is horse is located, if they are there. */

    }

    /**
     * Produces the contents of the array to the terminal. Each
     * horse in the array should have it's name displayed which occupies
     * a stall or the word "Empty" if no horse is there.
     */
    public static void displayBarn ( ? ) {
        /* Task 2: Complete the method below so it properly displays the
           contents of the Barn */
        String result = "Barn: ";
        
        System.out.println ( result );
    }
}