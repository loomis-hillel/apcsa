import java.util.ArrayList;

public class Speak {
    public static void main ( String [] args ) {
        
        // Instantiate an object and make it speak.
        Animal a = ?;
        System.out.println ( a.speak() );
    }
}