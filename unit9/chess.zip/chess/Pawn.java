import java.util.ArrayList;

public class Pawn extends Piece {

    private boolean moved;

    public Pawn(Coord coordinates, int color) {
        super(coordinates, color);
        moved = false;
    }

    public Pawn(int row, int col, int color) {
        super(row, col, color);
    }

    public ArrayList<Coord> getValidMoves ( Piece [][] board  ) {
        ArrayList<Coord> moves = new ArrayList<Coord>(32);
        Coord c = getCoordinates();
        int dir = -1;
        if ( getColor() == Piece.WHITE ) {
            dir = 1;
        }

        if ( c.getRow()+dir < 7 && c.getRow()+dir > 0 ) {
            if ( board[c.getRow()+dir][c.getCol()] == null ){
                moves.add ( new Coord(c.getRow()+dir, c.getCol() ) );
                if ( moved = false && board[c.getRow()+dir*2][c.getCol()] == null ) {
                    moves.add ( new Coord(c.getRow()+dir*2, c.getCol() ) );
                }
            }
            if ( c.getCol() > 0 && board[c.getRow()+dir][c.getCol()-1] != null &&
                 board[c.getRow()+dir][c.getCol()-1].getColor() != getColor() ){
                moves.add ( new Coord(c.getRow()+dir,c.getCol()-1) );
            }
            if ( c.getCol() < 7 && board[c.getRow()+dir][c.getCol()+1] != null &&
                 board[c.getRow()+dir][c.getCol()+1].getColor() != getColor() ){
                moves.add ( new Coord(c.getRow()+dir,c.getCol()+1) );
            }
        }

        return moves;
    }

    public String toString ( ) {
        if ( getColor() == WHITE )
            return "P";
        else
            return "\uA7FC";
    }

}
