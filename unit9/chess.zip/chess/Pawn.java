import java.util.ArrayList;

/**
 * A pawn piece.
 * @author Ken Loomis
 * @version 3/11/25
 */
public class Pawn extends Piece {

    private boolean moved;

    public Pawn(Coord coordinates, int color) {
        super(coordinates, color);
        moved = false;
    }

    public Pawn(int row, int col, int color) {
        super(row, col, color);
    }

    public ArrayList<Coord> getValidMoves ( Piece [][] board  ) {
        ArrayList<Coord> moves = new ArrayList<Coord>(32);
        Coord coord = getCoordinates();
        int dir = -1;
        if ( getColor() == Piece.BLACK ) {
            dir = 1;
        }

        int r = coord.getRow();
        int c = coord.getCol();
        if ( r+dir < 7 && r+dir > 0 ) {
            if ( board[r+dir][c] == null ){
                moves.add ( new Coord(r+dir, c) );
                if ( moved == false && ( board[r+dir+dir][c] == null ) ) {
                    moves.add ( new Coord(r+dir+dir, c) );
                }
            }
            if ( c > 0 && board[r+dir][c-1] != null &&
                          board[r+dir][c-1].getColor() != getColor() ){
                moves.add ( new Coord(r+dir,c-1) );
            }
            if ( c < 7 && board[r+dir][c+1] != null &&
                                   board[r+dir][c+1].getColor() != getColor() ){
                moves.add ( new Coord(r+dir,c+1) );
            }
        }

        return moves;
    }

    public Piece move ( Coord coordinates, Piece [][] board  ) {
        moved = true;
        return super.move( coordinates, board );
    }

    public String toString ( ) {
        if ( getColor() == WHITE )
            return "P";
        else
            return "\uA7FC";
    }

}
