import java.util.ArrayList;

/**
 * A chess piece. 
 * @author Ken Loomis
 * @version 3/11/25
 */
public class Piece {

    public static final int WHITE = 0;
    public static final int BLACK = 1;
    private Coord coordinates;
    private int color;

    public Piece(Coord coordinates, int color) {
        this.coordinates = coordinates;
        if ( color < 0 || color > 1 )
            throw new IllegalArgumentException( "Invalid color code." );
        this.color = color;
    }

    public Piece(int row, int col, int color) {
        this ( new Coord( row, col ), color );
    }

    public Coord getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(Coord coordinates) {
        this.coordinates = coordinates;
    }

    public int getColor() {
        return color;
    }

    public ArrayList<Coord> getValidMoves ( Piece [][] board  ) {
        return new ArrayList<Coord>(1);
    }

    public Piece move ( Coord coordinates, Piece [][] board  ) {
        Piece p = board[coordinates.getRow()][coordinates.getCol()];
        board[coordinates.getRow()][coordinates.getCol()] = this;
        int r = getCoordinates().getRow();
        int c = getCoordinates().getCol();
        board[r][c] = null;
        this.setCoordinates ( coordinates );
        return p;
    }



}
