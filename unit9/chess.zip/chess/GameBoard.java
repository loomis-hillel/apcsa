import java.util.ArrayList;

/**
 * A simple game chess game board
 * @author Ken Loomis
 * @version 3/11/25
 */
public class GameBoard {

    private Piece [] [] board;
    private ArrayList<Piece> pool;


    public GameBoard () {
        board = new Piece [8][8];
        for ( int i = 0; i < board[1].length; i++ ) {
            board[1][i] = new Pawn ( 1, i, Piece.BLACK );
            board[6][i] = new Pawn ( 6, i, Piece.WHITE );
        }

        pool = new ArrayList<Piece>(32);
    }

    public ArrayList<Coord> getMoves ( Coord coordinates, int turn ) {
        int r = coordinates.getRow();
        int c = coordinates.getCol();
        if ( board[r][c] == null ||
             board[r][c].getColor() != turn ) {
            return new ArrayList<Coord>(1);
        }
        return board[r][c].getValidMoves( board );
    }

    public void doMove ( Coord coordinates, Coord newCoordinates ) {
        Piece captured =
            board[coordinates.getRow()][coordinates.getCol()].move( newCoordinates, board );
        if ( captured != null ) {
            System.out.println ( "Captured: " + captured );
        }

    }

    public String toString () {
        String s = "";
        for ( Piece [] row: board ) {
            for ( Piece piece: row ) {
                if ( piece == null ) {
                    s += ". ";
                } else {
                    s += piece + " ";
                }
            }
            s += "\n";
        }
        return s;
    }

    public Piece[][] getBoard() {
        return board;
    }

}
