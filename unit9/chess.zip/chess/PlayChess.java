import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 * Plays a simplified version of chess with only
 * pawn. Player wins when they reach the other side
 * of the baord with 1 pawn.
 * @author Ken Loomis
 * @version 3/11/25
 */
public class PlayChess {
    public static void main ( String [] args ) {
        Scanner keyboard = new Scanner ( System.in );
        GameBoard game = new GameBoard();
        ArrayList<Coord> moveables = new ArrayList<Coord>(16);
        System.out.println ( "Welcome! -- First Move DEMO --" );

        int turn = Piece.WHITE;
        boolean playing = true;
        System.out.println ( game );
        while ( playing ) {
            moveables.clear();
            System.out.println( "\nValid Moves: " );
            for ( int r = 0; r < 8; r++ ) {
                for ( int c = 0; c < 8; c++ ) {
                    Coord coordinates = new Coord ( r, c );
                    if ( game.getMoves( coordinates, turn ).size() > 0 ){
                        System.out.print( moveables.size() + " " );
                        moveables.add( coordinates );

                    } else {
                        System.out.print( ". " );
                    }
                }
                System.out.println( );
            }
            Collections.sort ( moveables );
            System.out.print( "Select piece to move: " );
            int choice;
            do {
                choice = keyboard.nextInt();
            } while ( choice < 0 && choice >= moveables.size() );
            System.out.println ( moveables.get(choice) );
            ArrayList<Coord> moves = game.getMoves( moveables.get(choice), turn );
            Collections.sort ( moves );
            System.out.println(moves);
            for ( int r = 0; r < 8; r++ ) {
                for ( int c = 0; c < 8; c++ ) {
                    Coord coordinates = new Coord( r, c );
                    if ( moves.contains( coordinates ) ) {
                        System.out.print( moves.indexOf( coordinates ) + " " );
                    } else {
                        System.out.print( ". " );
                    }
                }
                System.out.println( );
            }
            int choice2;
            do {
                choice2 = keyboard.nextInt();
            } while ( choice2 < 0 && choice2 >= moves.size() );
            game.doMove ( moveables.get(choice), moves.get(choice2) );
            System.out.println ( game );
            turn = (turn + 1) % 2;
            playing = !checkWin();

        }
        System.out.println( "You win!" );

    }

    private boolean checkWin ( ) {
        int r = 0;
        for ( int c=0; c<8; c++ ) {
            if ( board[r][c] != null &&
                 board[r][c].getColor() == Piece.WHITE ) {
                    return true;
            }
        }
        r = 7;
        for ( int c=0; c<8; c++ ) {
            if ( board[r][c] != null &&
                 board[r][c].getColor() == Piece.BLACK ) {
                    return true;
            }
        }
        return false;
    }
}
