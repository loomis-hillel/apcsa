/**
 * A coordinate of a gameboard
 * @author Ken Loomis
 * @version 3/11/25
 */
public class Coord implements Comparable<Coord> {

    private int row;
    private int col;
    private final int MAX = 8;

    public Coord(int row, int col) {
        if ( row < 0 || col < 0 || row >= MAX || col >= MAX )
            throw new IllegalArgumentException ( "Coordinates out of range" );
        this.row = row;
        this.col = col;
    }

    public Coord ( Coord coordinates ) {
        this.row = coordinates.getRow();
        this.col = coordinates.getCol();
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        if ( row >= 0 && row < MAX )
            this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        if ( col >= 0 && col < MAX )
            this.col = col;
    }

    public boolean equals ( Object other ) {
        if ( this == other ) { return true; }
        if ( other instanceof Coord ) {
            return this.row == ((Coord)other).row && this.col == ((Coord)other).col;
        }
        return false;

    }

    public int compareTo ( Coord other ) {
        if ( this.row == other.row ) {
            return this.col - other.col;
        }
        return this.row - other.row;
    }

    @Override
    public String toString() {
        return "Coord [" + row + ", " + col + "]";
    }

}
