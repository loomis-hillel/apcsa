/**
 * A pet that has an owner and an animal type.
 * @author Ken Loomis
 */
public class Pet implements Comparable<Pet> {

	/** The pet's name **/
    private String name;
    /** The name of the pet's owner **/
    private String owner;
    /** The type of animal of the pet **/
    private String animalType;

    /** The list of allowed types of pets **/
    private static final String [] allowedTypes = {  "Cat", "Dog", "Mouse", "Snake", "Turtle" };


    @SuppressWarnings("unused")
    /**
     * Default constructor disabled
     */
	private Pet ( ) {
        this ( "Name", "Owner", "AnimalType" );
    }

    /**
     * Creates a pet based on the given name, owner's name, and animal type
     * @param name, name of the pet
     * @param owner, name of the pet's owner
     * @param type, the type of pet be one of: "Cat", "Dog", "Mouse", "Snake", or "Turtle"
     */
    public Pet ( String name, String owner, String type ) {
        this.name = name;
        this.owner = owner;
        setAnimalType ( type );
    }

    /**
     * Produces the name of the pet.
     * @return, the pet's name
     */
    public String getName() {
        return name;
    }

    /**
     * Produces the name of the pet's owner.
     * @return, the owner's name
     */
    public String getOwner() {
        return owner;
    }

    /**
     * Produces the type of the pet.
     * @return, the pet's type
     */
    public String getAnimalType() {
        return animalType;
    }

    /**
     * Sets the type of pet.
     * Precondition: the type is a valid pet type.
     * @param type, the animal type
     */
    private void setAnimalType( String type ) {
    	for ( String atype: allowedTypes ) {
    		if ( atype.equals( type ) ) {
    			this.animalType = type;
    			return;
    		}
    	}
    	throw new IllegalArgumentException ( "Invalid animal type: " + type );
    }

    @Override
    public boolean equals ( Object other ){
        if ( other instanceof Pet ){
            Pet otherPet = (Pet) other;
            return (this.name.equals(otherPet.name) &&
                this.owner.equals(otherPet.owner) &&
                this.animalType.equals(otherPet.animalType) );
        }
        return false;
    }

    @Override
    public String toString ( ) {
        return name + ": " + animalType +  " owned by " + owner;
    }

	@Override
	public int compareTo(Pet pet) {
		if ( pet == null ) {
			throw new IllegalArgumentException( "Cannot compare to a null value" );
		}
		if ( this.name.equals(pet.name) ) {
			if ( this.owner.equals( pet.owner ) ) {
				return this.animalType.compareTo ( pet.animalType );
			}
			return this.owner.compareTo ( pet.owner );
		}
		return this.name.compareTo( pet.name );
	}
}
