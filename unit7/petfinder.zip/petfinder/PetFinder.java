import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Creates an ArrayList of Pets and performs a sorting techniques to sort
 * the elements.
 * @author Ken Loomis  <--- Change this
 * @version
 */
public class PetFinder {

	private static final String FILENAME = "pets.csv";

	public static void main(String[] args) {

		ArrayList<Pet> pets = null;
		// This code loads the ArrayList of Pets using pets.csv file.
		try {
			pets = loadPets ( );
		} catch (FileNotFoundException e) {
			System.out.println ( "Unable to open pets.csv. Make sure the file is present." );
			System.exit(1);
		}

		// TODO: Task #3 - Add the code to create your pet (or make up the pet you want)
		// and add that pet to the ArrayList.


		Pet target = new Pet("Yertle", "Mr. Loomis", "Turtle" );
		// Change the target to Slinky when testing for an pet that does not exist.
		//Pet target = new Pet("Slinky", "Abraham", "Snake" );

		System.out.println( "Unsorted list: "  );
		for ( Pet pet: pets ) {
			System.out.println( "\t" + pet );
		}
		System.out.println( );

		// TODO: Task 4b - This currently uses insertion sort only.
		ArrayList<Pet> copy = insertionSort ( pets );
		// ArrayList<Pet> copy = bubbleSort ( pets );

		System.out.println( "Sorted list: "  );
		for ( Pet pet: copy ) {
			System.out.println( "\t" + pet );
		}

		System.out.println( "Linear search: "  );
		System.out.print( "\t" + target + " Found at " );
		long begin = System.nanoTime();
		int position = linearSearch ( target, copy );
		long end = System.nanoTime();
		System.out.println( position );
		System.out.println( "\ttime: " + (end-begin) + "ns" );
		System.out.println();

		System.out.println( "Binary search: "  );
		System.out.print( "\t" + target + " Found at " );
		begin = System.nanoTime();
		position = binarySearch ( target, copy );
		end = System.nanoTime();
		System.out.println( position );
		System.out.println ( "\ttime: " + (end-begin) + "ns" );

	}

	/**
	 * Performs a linear search for the given target Pet
	 * @param target, the Pet to search for
	 * @param list, the ArrayList of Pet to search through
	 * @return int, the index position of the Pet or -1 if not found.
	 */
	public static int linearSearch ( Pet target, ArrayList<Pet> list ) {
		// TODO: Task #1 - Add the linear search code below.

		return -1;
	}

	/**
	 * Performs a binary search for the given target strPeting
	 * @param target, the Pet to search for
	 * @param list, the ArrayList of Pets to search through
	 * @return int, the index position of the Pet or -1 if not found.
	 */
	public static int binarySearch ( Pet target, ArrayList<Pet> list ) {
		// TODO: Task #2 - Add the binary search code below.

		return -1;
	}

	/**
	 * Performs a insertion sort by copying given target ArrayList of Pets.
	 * and sorting the copy.
	 * @param list, the ArrayList of Pets to sort
	 * @return ArrayList<Pet>, a copy of the ArrayList sorted.
	 */
	public static ArrayList<Pet> insertionSort ( ArrayList<Pet> list ) {
		// Creates a copy of the ArrayList below
		ArrayList<Pet> copy = new ArrayList<Pet>(list.size());
		for ( Pet p: list ) {
			copy.add( p );
		}
		long begin = System.nanoTime();
		// Sorts the copy and returns it
		for ( int i = 1; i < copy.size(); i++ ){
			Pet x = copy.get(i);
			int j = i - 1;
			while ( j >= 0 && copy.get(j).compareTo (x) > 0 ) {
				copy.set( j+1, copy.get(j) );
				j = j - 1;
			}
			copy.set( j+1, x );
		}

		// Produces the runtime of the algorithm
		long end = System.nanoTime();
		System.out.println( "Insertion Sort\ttime: " + (end-begin) + "ns" );
		return copy;
	}

	/**
	 * Performs a bubble sort by copying given target ArrayList of Pets.
	 * and sorting the copy.
	 * @param list, the ArrayList of Pets to sort
	 * @return ArrayList<Pet>, a copy of the ArrayList sorted.
	 */
	public static ArrayList<Pet> bubbleSort ( ArrayList<Pet> list ) {
		// Creates a copy of the ArrayList
		ArrayList<Pet> copy = new ArrayList<Pet>(list.size());
		for ( Pet p: list ) {
			copy.add( p );
		}
		long begin = System.nanoTime();
		// TODO: Task #4 - Add the code below that sorts the copy according to bubble sort
		// algorithm and and returns it. The bubble sort algorithm is in the lab notes.

		// Add your code above this point to sort
		long end = System.nanoTime();
		System.out.println( "Bubble Sort\ttime: " + (end-begin) + "ns" );
		return copy;
	}

	/**
	 * Reads data out of the pets.csv file and produces a ArrayList of Pets
	 * as a result.
	 * @return ArrayList<Pet>, the list of pets from the file
	 * @throws FileNotFoundException is produces if the file is not found or
	 * 		is not accessible.
	 */
	private static ArrayList<Pet> loadPets ( ) throws FileNotFoundException {
		ArrayList<Pet> pets = new ArrayList<Pet>( );
		File csv = new File ( FILENAME );
		Scanner csvScanner = new Scanner ( csv );
		while ( csvScanner.hasNext() ) {
			String line = csvScanner.nextLine();
			Scanner lineScanner = new Scanner ( line );
			lineScanner.useDelimiter(",");
			Pet pet = new Pet(lineScanner.next(), lineScanner.next(), lineScanner.next());
			pets.add( pet );
			lineScanner.close();
		}
		csvScanner.close();
		return pets;
	}

}
