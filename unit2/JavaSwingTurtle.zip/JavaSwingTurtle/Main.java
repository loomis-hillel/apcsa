import java.awt.*;

public class Main {
  public static void main(String[] args) {
    World world = new World(400,400);
    Turtle myrtle;

    // Your code here

    world.setVisible(true);

    System.out.println ("Done");
  }
}

