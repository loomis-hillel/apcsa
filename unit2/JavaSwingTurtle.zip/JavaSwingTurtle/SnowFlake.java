import java.awt.*;

public class SnowFlake {
  public static void main(String[] args) {
    World world = new World(400,400);
    Turtle yertle = new Turtle(200, 50, world);
    yertle.setColor(Color.blue);
    // Arm 1
    yertle.penDown();
    yertle.moveTo(200, 250);

    yertle.penUp();
    yertle.moveTo(185, 240);
    yertle.penDown();
    yertle.moveTo(200, 225);
    yertle.moveTo(215, 240);

    yertle.penUp();
    yertle.moveTo(185, 60);
    yertle.penDown();
    yertle.moveTo(200, 75);
    yertle.moveTo(215, 60);

    // Arm 2
    yertle.penUp();
    yertle.moveTo(100, 100);
    yertle.penDown();
    yertle.moveTo(300, 200);

    yertle.penUp();
    yertle.moveTo(120, 95);
    yertle.penDown();
    yertle.moveTo(125, 115);
    yertle.moveTo(105, 125);

    yertle.penUp();
    yertle.moveTo(295, 175);
    yertle.penDown();
    yertle.moveTo(275, 185);
    yertle.moveTo(280, 205);

    // Arm 3
    yertle.penUp();
    yertle.moveTo(100, 200);
    yertle.penDown();
    yertle.moveTo(300, 100);

    yertle.penUp();
    yertle.moveTo(110, 175);
    yertle.penDown();
    yertle.moveTo(125, 190);
    yertle.moveTo(115, 215);

    yertle.penUp();
    yertle.moveTo(285, 85);
    yertle.penDown();
    yertle.moveTo(275, 115);
    yertle.moveTo(290, 125);

    yertle.penUp();
    yertle.moveTo(200, 150);

    world.setVisible(true);

    System.out.println ("Done");
  }
}

