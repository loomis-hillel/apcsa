public class Editor {
  /* Main method for testing */
  public static void main(String[] args) 
  {
    Picture pic = new Picture("image.jpg");
    pic.mirrorVertical();
    pic.write("output.jpg");
  }
}
