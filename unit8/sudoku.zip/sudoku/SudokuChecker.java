import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Checks to see if a given set of 9x9 numbers makes a 
 * valid Sudoku puzzle.
 * @author Ken Loomis
 */
public class SudokuChecker {

	public static void main(String[] args) {
		try {
			check ( "test1.dat" );
			check ( "test2.dat" );
			check ( "test3.dat" );
			check ( "test4.dat" );
		} catch ( Exception e ) {
			System.out.println ( "Failed to open file.\n" + e );
		}
	}

	/**
	  * Checks the given file to determine if it is a valid
	  * Sudoku solution or if it is not value. Outputs a 
	  * message indicating the result of the check.
	  * @param filename, the name of the file to check.
	  */
	public static void check ( String filename ) throws FileNotFoundException {
		System.out.print ( "Checking " + filename + ": " );
		File file = new File ( filename );
		Scanner read = new Scanner ( file );
		int [][] square = new int [9][9];
		boolean valid = true;
		
		for ( int r=0; r<square.length; r++ ) {
			for ( int c=0; c<square[r].length; c++ ) {
				square[r][c] = read.nextInt();
			}
		}
		// Check rows 
		for ( int r=0; r<square.length; r++) {
			valid = valid && checkRow ( r, square );
		}

		// Check Columns
		for ( int c=0; c<square[0].length; c++) {
			valid = valid && checkColumn ( c, square );
		}

		// Check Quadrants
		for (int r=0; r<square.length; r+=3 ) {
			for ( int c=0; c<square[r].length; c+=3 ) {
				valid = valid && checkQuadrant ( r, c, square );
			}
		}
		
		if ( valid ) {
			System.out.println ( "Sudoku!!" );
		} else {
			System.out.println ( "Invalid" );
		}
		read.close();
	}

	/**
	  * Checks the row given to ensure it contains exactly the 
	  * values 1 through 9 (no duplicates).
	  * @param r, the row to check
	  * @param square, the Sudoku puzzle that contains the row
	  * @return boolean, true if the row is value or false if
	  *         it does not contain the expected values.
	  */
	public static boolean checkRow ( int r, int[][] square ) {
		int [] digits = new int [10];

		return true;
	}
	
	/**
	  * Checks the column given to ensure it contains exactly the 
	  * values 1 through 9 (no duplicates).
	  * @param c, the column to check
	  * @param square, the Sudoku puzzle that contains the row
	  * @return boolean, true if the row is value or false if
	  *         it does not contain the expected values.
	  */
	public static boolean checkColumn ( int c, int[][] square ) {
		int [] digits = new int [10];

		return true;
	}

	/**
	  * Checks the column given to ensure it contains exactly the 
	  * values 1 through 9 (no duplicates).
	  * @param r0, the top-most row of the quadrant to check
	  * @param c0, the left-most column of the quadrant to check
	  * @param square, the Sudoku puzzle that contains the row
	  * @return boolean, true if the row is value or false if
	  *         it does not contain the expected values.
	  */
	public static boolean checkQuadrant ( int r0, int c0, int[][] square ) {
		int [] digits = new int [10];

		return true;
	}
	
}
