/**
 * Tests the Worker class to make sure that it
 * operates correctly.
 * @author Ken Loomis
 * @version 2022
 */
public class TestWorker {

    public static void main ( String [] args ) {    
        // Make a worker and set hours
        Worker billy = new Worker ( "Billy", 10.0, 20 );
        billy.setHours( 35 );
        // Test net pay (before taxes)
        System.out.println ( "Net pay for " + billy.getHours() + ": $" + billy.netPay() );
        // Give billy a raise and more hours
        billy.setWage ( billy.getWage() * 1.10 ); // ten percent raise
        billy.setHours ( 45 );
        System.out.println ( "Net pay for " + billy.getHours() + ": $" + billy.netPay() );
        System.out.println ( "Take-home pay for " + billy.getHours() + ": $" + billy.takeHomePay(.17) );
    }
}
